OpenERP Java Api
================

A Java API to connect to OpenERP and manage data using the XMLRPC interface.

The API reduces the amount of boiler plate code needed to communicate with OpenERP by doing error checking and type conversions.

For more information, including a Wiki please see the project on SourceForge: [https://sourceforge.net/projects/openerpjavaapi/](https://sourceforge.net/projects/openerpjavaapi)

The project is realeased under the Apache V2 license starting from version 1.5.  Earlier versions are dual licenced and developers can choose between LGPL3 (original license) and Apache V2.

